
% hit_or_miss: perform hit or miss on an image to find objects whose radius
% is ~9 or ~ 31
% five sizes: ~9, ~11, ~21, ~28, ~31 based on imtool measurement.
% return:
%       im1: (X erode A)
%       im2: (X^c erode B^S)
%       im3: ~(~im1 & ~im2) %%takes ~ because foreground is 0
%       im4: extended im3 based on the second largest circle's radius (r=29)
%       im5: image with selected circles only
%%%%%%%%%%%%% Function hit_or_miss %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Purpose:  
%      Implement hit-or-miss transform to find middle-sized disks 
%      Save the smallest and biggest disks in the image  
%
% Input Variables:
%      im       Input 2D image
%      
% Returned Results:
%      im1:     erosion of X by A
%      im2:     erosion of X^c by B^S
%      im3:     location of middle-sized disks ~(~im1 & ~im2)
%      im4:     image with only middle-sized disks
%      im5:     image with only the biggest and smallest disks.
%
% Processing Flow:
%      1.  Create two SE
%      2.  Implement hit-or-miss transform to find the location of 
%          middle-sized disks
%      3.  Extend 3 middle-sized disks to their original sizes
%      4.  Compute the image with the biggest and the smallest disks
%          
% Restrictions/Notes:
%      1. Note that we always create symetric SE, that is B = B^S
%      2. Foreground pixels are 0s, while background pixels are 1s
%      3. The size of five disks: ~9, ~11, ~21, ~28, ~31 are measured based
%      on imtool
%
% The following functions are called:
%      create_se.m      Create a SE
%      erode.m          Function of erode operation
%
%  Author:      Hao Zhou
%  Date:        1/24/2023 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [im1, im2, im3, im4, im5] = hit_or_miss(im)

    % Create two SE
    % A is bigger than smallest disk
    % B is smaller than the biggest disk
    A = create_se(19,9);
    B = create_se(63,30);

    % Implement hit-or-miss transform
    % im3 = (X erode A) & (X^c erode B^S)
    im1 = erode(im, A);
    im2 = erode(~im, ~B);
    im3 = ~(~im1 & ~im2);

    % Extend 3 middle-sized disks to their original sizes
    extend_r = 29; % the second largest disk's radius
    im4 = im3;
    [y, x] = size(im4);
%     offset = 0; % not used
    for r = 1 : y
        for c = 1 : x
            % If encounter a foreground pixel, extend it based on the 
            % second largest disk's radius
            if im3(r,c) == 0
                for rr = -(extend_r) : extend_r
                    for cc = -(extend_r) : extend_r
                        if im(r + rr,c + cc) == 0 % && (rr - r)^2 + (cc - c)^2 <= extend_r^2
                            im4(r + rr,c + cc) = 0;
                        end
                    end
                end
            end
        end
    end

    % Compute the image with the biggest and the smallest disks
    % Set different between clean image and image with only middle-sized disk
    im5 = ones(size(im));
    [y, x] = size(im5);
    for r = 1 : y
        for c = 1 : x
            if im(r, c) ~= im4(r, c)
                im5(r, c) = 0;
            end
        end
    end

end


