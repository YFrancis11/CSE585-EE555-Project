%%%%%%%%%%%%% main.m file %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Purpose:  
%      Implement hit-or-miss transform 
%      Detect the smallest and biggest disks in the image  
%
% Input Variables:
%      im       Input 2D image
%      
% Returned Results:
%      imb      A binary image
%      imc      A cleaned image without noise
%      im_      A image with selected disks
%
% Processing Flow:
%      1.  Load the input image
%      2.  Convert the RGB image to binary image
%      3.  Filter out salt-and-peper noise
%      4.  Implement hit-or-miss transform to find middle-sized disks
%      5.  Compute and save the image with the biggest and the smallest
%      disks as final output
%          
% Restrictions/Notes:
%      1. Note that we always create symetric SE, that is B = B^S
%      2. Foreground pixels are 0s, while background pixels are 1s.
%
% The following functions are called:
%      rgb2binary_.m    convert RGB image to binary image
%      denoise.m        remove salt-and-peper noise in a image
%      hit_or_miss.m    find desired circles using hit or miss transform
%
%  Author:      Hao Zhou
%  Date:        1/24/2023 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% Clean windows, workspace, etc
clear;
close all;
clc;

% Creat a folder for output results
mkdir 'results'

% Read in the original image
im = imread('RandomDisks-P10.jpg');

% Convert a RGB image to binary image
% Output:   imb: a binary image with type of bool(0/1)
imb = rgb2binary_(im);
imwrite(imb, 'results\imb.png');

% Filter out salt-and-peper noise
% Output:   imc: a cleaned image without noise
imc = denoise(imb);
imwrite(imc, 'results\imc.png');

% Object detection using hit-or-miss operation
% Output:   im1: image of erosion of X by A
%           im2: image of erosion of X^c by B^S
%           im3: location of middle-sized disks ~(~im1 & ~im2) (takes ~ 
%                beacuse foreground is 0)
%           im4: image with only middle-sized disks
%           im5: image with only the biggest and smallest disks.
[im1, im2, im3, im4, im5] = hit_or_miss(imc);
imwrite(im1, 'results\im1.png');
imwrite(im2, 'results\im2.png');
imwrite(im3, 'results\im3.png');
imwrite(im4, 'results\im4.png');
imwrite(im5, 'results\im5.png');

%%%%%%%%%%%%% End of the main.m file %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%