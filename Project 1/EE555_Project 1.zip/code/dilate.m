%%%%%%%%%%%%% Function erode %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Purpose:  
%      Function of dilate operation
%
% Input Variables:
%      im        Input 2D image
%      B         Input SE
%      
% Returned Results:
%      im2       The shape of the dilation of im by B
%
% Processing Flow:
%      1.  Get the 2D dimensions of inputs
%      2.  Applying dilation operation
%          
% Restrictions/Notes:
%      1. Note that we always create symetric SE, that is B = B^S
%      2. Foreground pixels are 0s, while background pixels are 1s.
%
% The following functions are called:
%      is_hit.m    Check if SE hits X
%
%  Author:      Hao Zhou
%  Date:        1/24/2023 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [im2] = dilate(im, B)

    im2 = ones(size(im), 'logical');

    % Get the 2D dimensions of inputs
    [y, x] = size(im);
    [m, n] = size(B);
    cutoff = (m - 1) / 2;

    % Applying dilation operation
    % Loop through all elements in the image (no borders)
    for i = 1 + cutoff : y - cutoff
        for j = 1 + cutoff : x - cutoff
            % Check whether B_z hits the image.
            if is_hit(im, B, i, j)
                im2(i, j) = 0; % Set to 0 (foreground)
            else
                im2(i, j) = 1; % Set to 1 (background)
            end
        end
    end

end