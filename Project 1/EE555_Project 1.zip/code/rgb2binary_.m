%%%%%%%%%%%%%  Function rgb2binary_ %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Purpose:  
%      Convert the RGB image to binary image
%
% Input Variables:
%      im       Input 2D image
%      
% Returned Results:
%      imb      A binary image
%
% Processing Flow:
%      1.  Convert the RGB image to grayscale image
%      2.  Convert the grayscale image to binary-valued image
%      3.  Set the image to bool type
%
%  Author:      Hao Zhou
%  Date:        1/24/2023 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [imb] = rgb2binary_(im)

    % Convert the RGB image to grayscale image
    imb = rgb2gray(im);
    [y, x] = size(imb);

    % Convert the grayscale image to binary-valued image
    % Set a threshold = 70, for the value of each pixels, if it is greater 
    % than threshold, then set it to black, otherwise set it to white.
    thre = 70;
    for i = 1 : x
        for j = 1 : y
            if imb(j, i) >= thre
                imb(j, i) = 255;
            else
                imb(j, i) = 0; 
            end
        end
    end

    % Set the image to bool type
    imb = logical(imb); 
end