%%%%%%%%%%%%% Function denoise %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Purpose:  
%      Filter out salt-and-peper noise with closing operation
%
% Input Variables:
%      imb       Input 2D image
%      
% Returned Results:
%      imc      A cleaned image without noise
%
% Processing Flow:
%      1.  Create a SE
%      2.  Apply closing operation to remove the noise
%          
% Restrictions/Notes:
%      1. Note that we always create symetric SE, that is B = B^S
%      2. Foreground pixels are 0s, while background pixels are 1s.
%
% The following functions are called:
%      create_se.m    Create a SE
%      erode.m        Function of erode operation
%      dilate.m       Function of dilate operation
%
%  Author:      Hao Zhou
%  Date:        1/24/2023 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


function [imc] = denoise(imb)

    % Create a SE circle with r=3 inside a 5 by 5 square
    B = create_se(7, 3);

    % Apply closing operation to remove the noise
    imc = erode(dilate(imb, B), B);
end
