%%%%%%%%%%%%% Function create_se %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Purpose:  
%      Create SE such that a circle resides in a square
%
% Input Variables:
%      size      The width of the square
%      radius    The radius of the circle in the square
%      
% Returned Results:
%      se        The SE
%
% Processing Flow:
%      1.  Judge the input parameters
%      2.  Create the SE based on the input parameters
%      3.  Show the shape of SE 
%          
%  Restrictions/Notes:
%      1. Note that we always create symetric SE, that is B = B^S
%      2. Foreground pixels are 0s, while background pixels are 1s.
%
%  Author:      Hao Zhou
%  Date:        1/24/2023 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [se] = create_se(size, radius)

    % Judge the input parameters are reasonable or not
    if size < radius || mod(size, 2) == 0 
        error('wrong size for the radius, and make sure size is odd for easier computations');
    end

    % Create SE based on the input parameters
    rows = size;
    cols = size;
    
    centerX = (cols + 1) / 2;
    centerY = (rows + 1) / 2;

    se = zeros(rows, cols, 'logical'); 
    
    for r = 1 : rows
        for c = 1 : cols
            if (r - centerY) ^ 2 + (c - centerX) ^ 2 <= radius ^ 2
                se(r, c) = 1;
            end
        end
    end

    % Show the shape of SE 
    imtool(se);