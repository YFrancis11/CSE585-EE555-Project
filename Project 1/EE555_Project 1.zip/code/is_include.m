%%%%%%%%%%%%% Function is_include %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Purpose:  
%      Check if SE is included in X
%
% Input Variables:
%      im        Input 2D image
%      B         Input SE
%      x         x-dimension of image
%      y         y-dimension of image
%      
% Returned Results:
%      include   SE is included in X
%        
%  Restrictions/Notes:
%      1. Note that we always create symetric SE, that is B = B^S
%      2. Foreground pixels are 0s, while background pixels are 1s.
%
%  Author:      Hao Zhou
%  Date:        1/24/2023 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [include] = is_include(im, B, x, y)

    [h, w] = size(B);
    include = true;

    r = (h + 1) / 2 ;

    for i = 1 : h
        for j = 1 : w
            % only consider valid elements in B 
            if B(i, j) == 1
                include = include & ~im(x + i - r, y + j - r);
            end
        end
    end

end







